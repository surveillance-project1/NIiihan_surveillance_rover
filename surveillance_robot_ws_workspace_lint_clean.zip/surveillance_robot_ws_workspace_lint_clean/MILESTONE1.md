# Milestone 1 — Jazzy/Harmonic robotics baseline

> Status: implemented and statically validated on the integration branch. ROS 2/Gazebo runtime acceptance is **NOT VERIFIED** on the current Amazon Linux build host because `ros2`, `colcon`, `xacro`, and `gz` are unavailable.

## Supported target

- Ubuntu 24.04
- ROS 2 Jazzy
- Gazebo Harmonic
- one simulation server, robot instance, controller chain, and authority per TF edge

## Build

```bash
cd surveillance_robot_ws
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --event-handlers console_direct+
source install/setup.bash
colcon test --event-handlers console_direct+
colcon test-result --verbose
```

## Mapping — one command

```bash
ros2 launch surveillance_robot_bringup demo_mapping.launch.py
```

In a second terminal, publish stamped teleoperation commands through the safety gate:

```bash
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args   -p stamped:=true -p frame_id:=base_footprint -r cmd_vel:=/cmd_vel_nav
```

Save the map without overwriting an approved version:

```bash
mkdir -p maps/construction_site_v1
ros2 run nav2_map_server map_saver_cli -f maps/construction_site_v1/site
```

Stop mapping with Ctrl-C and confirm all processes terminate.

## Localization/navigation — one command

```bash
ros2 launch surveillance_robot_bringup demo_navigation.launch.py   map:=$PWD/maps/construction_site_v1/site.yaml
```

Use RViz **2D Pose Estimate** before commanding navigation. The launch intentionally fails if the map YAML does not exist.

## Patrol/moving obstacle — one command

```bash
ros2 launch surveillance_robot_bringup demo_patrol.launch.py   map:=$PWD/maps/construction_site_v1/site.yaml
```

The patrol waits for Nav2, a healthy motion gate, and `map -> base_footprint`. The procedural world contains a collidable velocity-controlled obstacle that crosses the south route. Adjust `demo_route.yaml` only after validating coordinates against the saved map.

## Health and stop behavior

```bash
ros2 topic echo /diagnostics
ros2 topic echo /safety/stop_requested
ros2 service call /health/clear_faults std_srvs/srv/Trigger '{}'
```

`/cmd_vel_nav` is the only normal command input. `cmd_vel_safety_gate` is the sole publisher to controller input `/cmd_vel`. LiDAR, wheel odometry, fused odometry, critical TF, localization, or Nav2 failures latch the gate after startup grace. RGB, depth, and point-cloud faults report degraded capability without independently stopping 2D navigation.

## Canonical interfaces

| Interface | Owner |
|---|---|
| `/cmd_vel_nav` | Nav2 or stamped teleoperation, mutually exclusive by procedure |
| `/cmd_vel` | `cmd_vel_safety_gate` only |
| `/wheel/odom` | `diff_drive_controller` |
| `/odom` and `odom -> base_footprint` | EKF |
| `map -> odom` mapping | SLAM Toolbox |
| `map -> odom` navigation | AMCL |
| fixed robot/sensor TF | robot_state_publisher |
| `/scan`, `/lidar/points`, camera topics, `/imu/data` | one `ros_gz_bridge` instance |

## Runtime validation commands

```bash
ros2 control list_controllers
ros2 topic info /cmd_vel -v
ros2 topic info /wheel/odom -v
ros2 topic info /odom -v
ros2 topic hz /scan
ros2 topic hz /lidar/points
ros2 topic hz /camera/front/image_raw
ros2 topic hz /camera/front/depth/image_raw
ros2 topic hz /imu/data
ros2 run tf2_tools view_frames
ros2 action list
ros2 lifecycle nodes
```

Record acceptance evidence and metrics per run:

```bash
mkdir -p logs/run_1
ros2 bag record -o logs/run_1/mission   /tf /tf_static /scan /lidar/points /imu/data /wheel/odom /odom /map   /plan /local_plan /patrol/status /diagnostics /safety/stop_requested
# Optional host metrics (install Ubuntu package: sysstat)
pidstat -rud -p ALL 1 | tee logs/run_1/resources.txt
```

Repeat with unchanged parameters for `run_2` and `run_3`. Milestone completion remains blocked until all runtime acceptance items pass three consecutive times.

## Consistency tests

The Gazebo package registers four exact offline test files:

- `test_chunk5_integration.py`
- `test_milestone1_contracts.py`
- `test_sensor_contracts.py`
- `test_environment_contracts.py`

`colcon test` runs them through `ament_cmake_pytest`. Passing these tests is static validation, not Gazebo runtime acceptance.

## Known limits

- Dimensions, mass, wheelbase, track, inertia, covariance, speeds, and clearances are provisional simulation values—not physical calibration or certification.
- The Unitree-like model exposes a planar scan and point cloud but is not a vendor driver model.
- The fixed RGB/depth simulation represents the Orbbec sensor class, not calibrated Astra 2 intrinsics.
- The moving obstacle uses sensed collision geometry; its exact Harmonic VelocityControl behavior must be runtime-verified.
- No web application, gateway, ML, cloud, GNSS localization, docking, or production safety system is included.
