# Surveillance Robot — Milestone 1

ROS 2 Jazzy / Gazebo Harmonic robotics baseline for a four-wheel construction-site surveillance robot.

## Verification status

- **Source consistency:** repaired and statically checked.
- **Build:** must be verified in Ubuntu 24.04 / ROS 2 Jazzy.
- **Runtime:** **NOT VERIFIED** in this source-repair environment.
- **Milestone acceptance:** not complete until mapping, saved-map localization, Nav2, patrol, obstacle handling, replanning, and three consecutive runs pass.

See [MILESTONE1.md](MILESTONE1.md) for exact build, launch, validation, and evidence commands.

## Packages

| Package | Responsibility |
|---|---|
| `surveillance_robot_description` | Four-wheel Xacro model, inertias, sensor and robot frames |
| `surveillance_robot_gazebo` | Harmonic worlds, sensors, bridges, ros2_control, moving obstacle |
| `surveillance_robot_localization` | EKF, SLAM Toolbox, AMCL and map resources |
| `surveillance_robot_navigation` | Minimal Milestone 1 Nav2 servers and parameters |
| `surveillance_robot_patrol` | Ordered YAML waypoint executor and RViz markers |
| `surveillance_robot_health` | Stream/TF/Nav2 diagnostics and stamped velocity safety gate |
| `surveillance_robot_bringup` | One-command mapping, navigation and patrol composition |
| `surveillance_robot_interfaces` | Reserved empty interface scaffold; no custom interfaces required yet |
| `surveillance_robot_tools` | Reserved development-tools scaffold |

## Canonical ownership

```text
Mapping:    SLAM Toolbox  -> map -> odom
Navigation: AMCL          -> map -> odom
Odometry:   EKF           -> odom -> base_footprint and /odom
Kinematics: robot_state_publisher -> base_footprint -> base_link -> sensors/wheels
Control:    Nav2/teleop -> /cmd_vel_nav -> health gate -> /cmd_vel -> diff_drive_controller
Raw odom:   diff_drive_controller -> /wheel/odom (controller TF disabled)
```

The default world is the sensor-visible `construction_site_procedural`. The legacy `construction_site_chunk5` world is collision-only and is not the mapping/navigation acceptance environment.

## Quick build

```bash
cd surveillance_robot_ws
source /opt/ros/jazzy/setup.bash
rm -rf build install log
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --event-handlers console_direct+
source install/setup.bash
colcon test --event-handlers console_direct+
colcon test-result --verbose
```

No web application, gateway, cloud service, ML platform, GNSS localization, docking, or production safety system is part of this milestone.
