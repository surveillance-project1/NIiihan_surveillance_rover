# Milestone 1 implementation log

Base: `13a270b75bc4617d3b0012d98e0eb2cc58308a5c`  
Branch: `milestone1/robotics-baseline`

- Preserved Repo A’s modular Xacro, Harmonic bridge/control approach, thin launch ownership, Nav2 baseline, test world, and high-fidelity-world contracts.
- Replaced the provisional two-wheel physical model with a provisional rigid four-wheel skid-steer simulation model.
- Changed controller odometry to `/wheel/odom`, disabled its TF, and added EKF-owned `/odom` plus `odom -> base_footprint`.
- Added Unitree L2-like planar/cloud outputs, fixed front RGB/depth sensing, 100 Hz IMU configuration, explicit bridge YAML, and canonical frames.
- Added dedicated localization and health packages.
- Adapted Repo B’s Apache-2.0-declared procedural world; imported no Repo B runtime node, launch stack, dashboard, controller, odometry publisher, or generated artifact.
- Added a real collidable moving model and deterministic ROS-to-Gazebo velocity controller.
- Added a minimal YAML-driven patrol executor with global-path precheck, three total attempts, terminal results, and RViz markers.
- Added one-command mapping/navigation/patrol launch files and static/offline architecture tests.

## Consistency repair

- Added and registered exact sensor and environment contract tests.
- Replaced the all-inclusive Jazzy Nav2 bringup include with the minimal Milestone 1 node set, preventing route/docking/collision-monitor command-chain conflicts.
- Updated diff-drive limits to current Jazzy parameter names.
- Added message-header timestamp and camera-info health checks.
- Implemented the `SKIPPED` patrol state for no-global-path outcomes and removed an unused parameter.
- Removed the unresolved visual URI from the collision-only legacy world.
- Reconciled manifests with runtime/documented dependencies.
- Replaced stale two-wheel/chunk documentation with current commands and ownership.
