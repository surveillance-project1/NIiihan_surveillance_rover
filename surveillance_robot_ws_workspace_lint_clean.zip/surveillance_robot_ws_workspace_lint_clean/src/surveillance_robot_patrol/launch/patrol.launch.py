# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    default = PathJoinSubstitution(
        [FindPackageShare('surveillance_robot_patrol'), 'config', 'demo_route.yaml']
    )
    return LaunchDescription(
        [
            DeclareLaunchArgument('route_file', default_value=default),
            DeclareLaunchArgument('max_attempts', default_value='3'),
            DeclareLaunchArgument('auto_start', default_value='true'),
            Node(
                package='surveillance_robot_patrol',
                executable='waypoint_patrol',
                name='waypoint_patrol',
                output='screen',
                parameters=[
                    {
                        'use_sim_time': True,
                        'route_file': LaunchConfiguration('route_file'),
                        'max_attempts': ParameterValue(
                            LaunchConfiguration('max_attempts'), value_type=int
                        ),
                        'auto_start': ParameterValue(
                            LaunchConfiguration('auto_start'), value_type=bool
                        ),
                    }
                ],
            ),
        ]
    )
