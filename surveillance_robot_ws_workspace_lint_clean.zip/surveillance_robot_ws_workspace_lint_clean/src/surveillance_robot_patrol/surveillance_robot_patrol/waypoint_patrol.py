# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Minimal deterministic YAML route executor for Milestone 1."""

import json
import math

from action_msgs.msg import GoalStatus
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import ComputePathToPose, NavigateToPose
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from std_msgs.msg import Bool, String
from tf2_ros import Buffer, TransformListener
from visualization_msgs.msg import Marker, MarkerArray
import yaml


class WaypointPatrol(Node):
    def __init__(self):
        super().__init__('waypoint_patrol')
        self.declare_parameter('route_file', '')
        self.declare_parameter('max_attempts', 3)
        self.declare_parameter('auto_start', True)
        self.route = self.load_route(self.get_parameter('route_file').value)
        self.index = 0
        self.active = False
        self.finished = False
        self.navigate = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.compute = ActionClient(self, ComputePathToPose, 'compute_path_to_pose')
        self.tf = Buffer()
        self.tf_listener = TransformListener(self.tf, self)
        self.safety_stop = True
        self.create_subscription(Bool, '/safety/stop_requested', self.safety_callback, 10)
        self.status_pub = self.create_publisher(String, '/patrol/status', 10)
        self.marker_pub = self.create_publisher(MarkerArray, '/patrol/markers', 10)
        self.create_timer(1.0, self.tick)
        self.publish('PENDING', 'route loaded')

    def load_route(self, path):
        if not path:
            raise RuntimeError('route_file parameter is required')
        with open(path, encoding='utf-8') as f:
            data = yaml.safe_load(f)
        if data.get('frame_id', 'map') != 'map':
            raise ValueError('Milestone 1 routes must use map frame')
        route = []
        for i, w in enumerate(data.get('waypoints', [])):
            for key in ('name', 'x', 'y', 'yaw'):
                if key not in w:
                    raise ValueError(f'waypoint {i} missing {key}')
            if not all(math.isfinite(float(w[k])) for k in ('x', 'y', 'yaw')):
                raise ValueError(f'waypoint {i} has non-finite pose')
            route.append(
                {
                    'name': str(w['name']),
                    'x': float(w['x']),
                    'y': float(w['y']),
                    'yaw': float(w['yaw']),
                    'state': 'PENDING',
                    'attempts': 0,
                    'reason': '',
                }
            )
        if not route:
            raise ValueError('route contains no waypoints')
        self.route_name = str(data.get('route_name', 'demo_route'))
        return route

    def pose(self, w):
        p = PoseStamped()
        p.header.frame_id = 'map'
        p.header.stamp = self.get_clock().now().to_msg()
        p.pose.position.x = w['x']
        p.pose.position.y = w['y']
        p.pose.orientation.z = math.sin(w['yaw'] / 2)
        p.pose.orientation.w = math.cos(w['yaw'] / 2)
        return p

    def safety_callback(self, msg):
        self.safety_stop = bool(msg.data)

    def tick(self):
        self.publish_markers()
        if self.finished or self.active or not bool(self.get_parameter('auto_start').value):
            return
        if not self.navigate.server_is_ready() or not self.compute.server_is_ready():
            self.publish('PENDING', 'waiting for active Nav2 action servers')
            return
        if self.safety_stop:
            self.publish('PENDING', 'waiting for healthy motion gate')
            return
        if not self.tf.can_transform('map', 'base_footprint', rclpy.time.Time()):
            self.publish('PENDING', 'waiting for localization / initial pose')
            return
        self.start_current()

    def start_current(self):
        if self.index >= len(self.route):
            self.finished = True
            self.publish('SUCCEEDED', 'route complete')
            return
        self.active = True
        w = self.route[self.index]
        w['state'] = 'ACTIVE'
        self.publish('ACTIVE', 'checking global path')
        goal = ComputePathToPose.Goal()
        goal.goal = self.pose(w)
        goal.use_start = False
        fut = self.compute.send_goal_async(goal)
        fut.add_done_callback(self.path_goal_response)

    def path_goal_response(self, fut):
        handle = fut.result()
        if not handle.accepted:
            self.fail_or_skip('NO_GLOBAL_PATH: planner rejected request', count_attempt=False)
            return
        result = handle.get_result_async()
        result.add_done_callback(self.path_result)

    def path_result(self, fut):
        result = fut.result()
        if result.status != GoalStatus.STATUS_SUCCEEDED or not result.result.path.poses:
            self.fail_or_skip('NO_GLOBAL_PATH: empty/failed plan', count_attempt=False)
            return
        self.send_navigation()

    def send_navigation(self):
        w = self.route[self.index]
        w['attempts'] += 1
        self.publish(
            'ACTIVE',
            f'navigation attempt {w["attempts"]}/{self.get_parameter("max_attempts").value}',
        )
        goal = NavigateToPose.Goal()
        goal.pose = self.pose(w)
        fut = self.navigate.send_goal_async(goal)
        fut.add_done_callback(self.nav_goal_response)

    def nav_goal_response(self, fut):
        handle = fut.result()
        if not handle.accepted:
            self.fail_or_skip('EXECUTION_FAILURE: goal rejected', count_attempt=True)
            return
        result = handle.get_result_async()
        result.add_done_callback(self.nav_result)

    def nav_result(self, fut):
        result = fut.result()
        if result.status == GoalStatus.STATUS_SUCCEEDED:
            w = self.route[self.index]
            w['state'] = 'SUCCEEDED'
            w['reason'] = ''
            self.publish('SUCCEEDED', 'waypoint reached')
            self.index += 1
            self.active = False
        else:
            self.fail_or_skip(
                f'EXECUTION_FAILURE: action status {result.status}', count_attempt=True
            )

    def fail_or_skip(self, reason, count_attempt):
        w = self.route[self.index]
        w['reason'] = reason
        maximum = int(self.get_parameter('max_attempts').value)
        if not count_attempt:
            w['state'] = 'SKIPPED'
            self.publish('SKIPPED', reason)
            self.index += 1
            self.active = False
            return
        if count_attempt and w['attempts'] < maximum:
            self.get_logger().warning(f'{w["name"]}: {reason}; retrying')
            self.active = False
            return
        w['state'] = 'FAILED'
        self.publish('FAILED', reason)
        self.index += 1
        self.active = False

    def publish(self, state, detail):
        current = self.route[self.index]['name'] if self.index < len(self.route) else None
        payload = {
            'route': self.route_name,
            'state': state,
            'current_waypoint': current,
            'index': self.index,
            'total': len(self.route),
            'detail': detail,
            'waypoints': [
                {k: w[k] for k in ('name', 'state', 'attempts', 'reason')} for w in self.route
            ],
        }
        msg = String()
        msg.data = json.dumps(payload, separators=(',', ':'))
        self.status_pub.publish(msg)
        self.get_logger().info(msg.data)

    def publish_markers(self):
        arr = MarkerArray()
        colors = {
            'PENDING': (0.5, 0.5, 0.5),
            'ACTIVE': (1.0, 0.7, 0.0),
            'SUCCEEDED': (0.0, 0.8, 0.2),
            'FAILED': (1.0, 0.0, 0.0),
            'SKIPPED': (0.4, 0.4, 1.0),
        }
        for i, w in enumerate(self.route):
            m = Marker()
            m.header.frame_id = 'map'
            m.header.stamp = self.get_clock().now().to_msg()
            m.ns = 'patrol_waypoints'
            m.id = i
            m.type = Marker.ARROW
            m.action = Marker.ADD
            m.pose = self.pose(w).pose
            m.scale.x = 0.55
            m.scale.y = 0.12
            m.scale.z = 0.12
            m.color.a = 1.0
            m.color.r, m.color.g, m.color.b = colors[w['state']]
            arr.markers.append(m)
        self.marker_pub.publish(arr)


def main(args=None):
    rclpy.init(args=args)
    try:
        n = WaypointPatrol()
        rclpy.spin(n)
    except (KeyboardInterrupt, RuntimeError, ValueError) as e:
        if 'n' in locals():
            n.get_logger().error(str(e))
    finally:
        if 'n' in locals():
            n.destroy_node()
        rclpy.shutdown()
