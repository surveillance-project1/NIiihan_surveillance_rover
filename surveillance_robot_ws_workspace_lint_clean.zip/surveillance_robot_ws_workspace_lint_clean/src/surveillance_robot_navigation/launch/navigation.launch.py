# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Launch only the Nav2 servers required by Milestone 1.

This deliberately avoids nav2_bringup/navigation_launch.py because Jazzy's
stock launch also starts route, docking, velocity-smoother, and collision-monitor
servers. Those components are outside this milestone and would create a second
cmd_vel chain alongside surveillance_robot_health.
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterFile
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    params_file = LaunchConfiguration('params_file')
    autostart = LaunchConfiguration('autostart')
    configured_params = ParameterFile(params_file, allow_substs=True)
    tf_remaps = [('/tf', 'tf'), ('/tf_static', 'tf_static')]
    cmd_remaps = tf_remaps + [('cmd_vel', '/cmd_vel_nav')]
    lifecycle_nodes = [
        'controller_server',
        'smoother_server',
        'planner_server',
        'behavior_server',
        'bt_navigator',
        'waypoint_follower',
    ]

    nodes = [
        Node(
            package='nav2_controller',
            executable='controller_server',
            name='controller_server',
            output='screen',
            parameters=[configured_params],
            remappings=cmd_remaps,
        ),
        Node(
            package='nav2_smoother',
            executable='smoother_server',
            name='smoother_server',
            output='screen',
            parameters=[configured_params],
            remappings=tf_remaps,
        ),
        Node(
            package='nav2_planner',
            executable='planner_server',
            name='planner_server',
            output='screen',
            parameters=[configured_params],
            remappings=tf_remaps,
        ),
        Node(
            package='nav2_behaviors',
            executable='behavior_server',
            name='behavior_server',
            output='screen',
            parameters=[configured_params],
            remappings=cmd_remaps,
        ),
        Node(
            package='nav2_bt_navigator',
            executable='bt_navigator',
            name='bt_navigator',
            output='screen',
            parameters=[configured_params],
            remappings=tf_remaps,
        ),
        Node(
            package='nav2_waypoint_follower',
            executable='waypoint_follower',
            name='waypoint_follower',
            output='screen',
            parameters=[configured_params],
            remappings=tf_remaps,
        ),
        Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            name='lifecycle_manager_navigation',
            output='screen',
            parameters=[
                {
                    'use_sim_time': True,
                    'autostart': autostart,
                    'node_names': lifecycle_nodes,
                }
            ],
        ),
    ]

    return LaunchDescription(
        [
            DeclareLaunchArgument('autostart', default_value='true'),
            DeclareLaunchArgument(
                'params_file',
                default_value=PathJoinSubstitution(
                    [
                        FindPackageShare('surveillance_robot_navigation'),
                        'config',
                        'nav2_params.yaml',
                    ]
                ),
            ),
            *nodes,
        ]
    )
