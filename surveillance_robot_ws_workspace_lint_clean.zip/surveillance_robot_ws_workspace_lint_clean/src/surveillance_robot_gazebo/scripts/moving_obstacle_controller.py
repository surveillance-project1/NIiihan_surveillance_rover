#!/usr/bin/env python3
# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Publish a repeatable crossing motion for the collidable Gazebo obstacle."""

from geometry_msgs.msg import Twist
import rclpy
from rclpy.node import Node


class MovingObstacleController(Node):
    def __init__(self):
        super().__init__('moving_obstacle_controller')
        self.declare_parameter('speed', 0.7)
        self.declare_parameter('travel_time', 8.0)
        self.declare_parameter('pause_time', 4.0)
        self.pub = self.create_publisher(Twist, '/model/moving_obstacle/cmd_vel', 10)
        self.started = self.get_clock().now()
        self.create_timer(0.05, self.tick)

    def tick(self):
        travel = float(self.get_parameter('travel_time').value)
        pause = float(self.get_parameter('pause_time').value)
        period = 2.0 * (travel + pause)
        t = (self.get_clock().now() - self.started).nanoseconds / 1e9 % period
        msg = Twist()
        speed = float(self.get_parameter('speed').value)
        if t < travel:
            msg.linear.y = speed
        elif t < travel + pause:
            msg.linear.y = 0.0
        elif t < 2 * travel + pause:
            msg.linear.y = -speed
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = MovingObstacleController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.pub.publish(Twist())
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
