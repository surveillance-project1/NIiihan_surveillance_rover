# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Offline Gazebo world, asset, moving-obstacle, and route contracts."""

import ast
from pathlib import Path
import xml.etree.ElementTree as ET

import yaml

PACKAGE = Path(__file__).resolve().parents[1]
SRC = PACKAGE.parent


def test_all_world_relative_uris_exist():
    for world_path in (PACKAGE / 'worlds').glob('*.sdf'):
        root = ET.parse(world_path).getroot()
        for uri in root.findall('.//uri'):
            value = (uri.text or '').strip()
            assert not value.startswith('model://')
            if value and '://' not in value:
                assert (world_path.parent / value).is_file(), (world_path, value)


def test_procedural_world_is_sensor_visible_and_moving_obstacle_is_physical():
    world = ET.parse(PACKAGE / 'worlds/construction_site_procedural.sdf').getroot().find('world')
    assert world.get('name') == 'construction_site_procedural'
    assert len(world.findall('model')) > 50
    moving = world.find("model[@name='moving_obstacle']")
    assert moving is not None
    assert moving.find('link/collision') is not None
    plugin = moving.find('plugin')
    assert plugin.get('filename') == 'gz-sim-velocity-control-system'
    assert plugin.get('name') == 'gz::sim::systems::VelocityControl'


def test_launch_has_one_server_one_spawn_and_one_controller_chain():
    launch_path = PACKAGE / 'launch/simulation.launch.py'
    tree = ast.parse(launch_path.read_text())
    calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)]
    includes = [
        node for node in calls if getattr(node.func, 'id', '') == 'IncludeLaunchDescription'
    ]
    nodes = [node for node in calls if getattr(node.func, 'id', '') == 'Node']
    executables = [
        keyword.value.value
        for node in nodes
        for keyword in node.keywords
        if keyword.arg == 'executable' and isinstance(keyword.value, ast.Constant)
    ]
    assert len(includes) == 1
    assert executables.count('create') == 1
    assert executables.count('robot_state_publisher') == 1
    assert executables.count('spawner') == 2
    assert 'static_transform_publisher' not in executables


def test_demo_route_is_installed_map_frame_data_inside_world_bounds():
    route_path = SRC / 'surveillance_robot_patrol/config/demo_route.yaml'
    route = yaml.safe_load(route_path.read_text())
    assert route['frame_id'] == 'map'
    assert len(route['waypoints']) >= 2
    for waypoint in route['waypoints']:
        assert -25.0 <= float(waypoint['x']) <= 25.0
        assert -25.0 <= float(waypoint['y']) <= 25.0
    setup = (SRC / 'surveillance_robot_patrol/setup.py').read_text()
    assert "glob('config/*.yaml')" in setup
