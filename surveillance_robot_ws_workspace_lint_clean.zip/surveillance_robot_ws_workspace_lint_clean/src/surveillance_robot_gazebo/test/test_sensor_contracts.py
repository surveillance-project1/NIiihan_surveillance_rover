# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Offline sensor/topic/frame/health contracts for the exact delivered source."""

from pathlib import Path
import xml.etree.ElementTree as ET

import yaml

PACKAGE = Path(__file__).resolve().parents[1]
SRC = PACKAGE.parent


def test_required_bridge_topics_are_unique_and_typed():
    bridges = yaml.safe_load((PACKAGE / 'config/sensor_bridges.yaml').read_text())
    by_ros = {entry['ros_topic_name']: entry for entry in bridges}
    assert len(by_ros) == len(bridges)
    expected = {
        '/scan': 'sensor_msgs/msg/LaserScan',
        '/lidar/points': 'sensor_msgs/msg/PointCloud2',
        '/camera/front/image_raw': 'sensor_msgs/msg/Image',
        '/camera/front/camera_info': 'sensor_msgs/msg/CameraInfo',
        '/camera/front/depth/image_raw': 'sensor_msgs/msg/Image',
        '/camera/front/depth/camera_info': 'sensor_msgs/msg/CameraInfo',
        '/imu/data': 'sensor_msgs/msg/Imu',
    }
    for topic, message_type in expected.items():
        assert by_ros[topic]['ros_type_name'] == message_type
        assert by_ros[topic]['direction'] == 'GZ_TO_ROS'
    assert by_ros['/lidar/points']['gz_topic_name'] == '/scan/points'


def test_gazebo_sensor_topics_and_frames_match_bridge_contract():
    root = ET.parse(PACKAGE / 'urdf/gazebo_sensors.xacro').getroot()
    sensors = {
        sensor.findtext('topic'): (
            sensor.get('type'),
            sensor.findtext('gz_frame_id'),
        )
        for sensor in root.findall('.//sensor')
    }
    assert sensors['/scan'] == ('gpu_lidar', 'lidar_link')
    assert sensors['/camera/front/image_raw'] == (
        'camera',
        'camera_front_optical_frame',
    )
    assert sensors['/camera/front/depth/image_raw'] == (
        'depth_camera',
        'camera_front_depth_optical_frame',
    )
    assert sensors['/imu/data'] == ('imu', 'imu_link')


def test_health_monitor_observes_every_required_stream_and_header_timestamp():
    health_monitor = (
        SRC / 'surveillance_robot_health' / 'surveillance_robot_health' / 'health_monitor.py'
    )
    source = health_monitor.read_text()
    for topic in (
        '/scan',
        '/lidar/points',
        '/camera/front/image_raw',
        '/camera/front/camera_info',
        '/camera/front/depth/image_raw',
        '/camera/front/depth/camera_info',
        '/imu/data',
        '/wheel/odom',
        '/odom',
    ):
        assert repr(topic) in source
    assert 'msg_stamp' in source
    assert 'message timestamp stale' in source
    assert 'message timestamp is' in source


def test_command_and_odometry_ownership_are_single_chain():
    simulation = (PACKAGE / 'launch/simulation.launch.py').read_text()
    controller = yaml.safe_load((PACKAGE / 'config/controllers.yaml').read_text())
    params = controller['diff_drive_controller']['ros__parameters']
    gate = (
        SRC / 'surveillance_robot_health' / 'surveillance_robot_health' / 'cmd_vel_safety_gate.py'
    ).read_text()
    ekf = yaml.safe_load((SRC / 'surveillance_robot_localization' / 'config/ekf.yaml').read_text())
    assert '-r ~/cmd_vel:=/cmd_vel -r ~/odom:=/wheel/odom' in simulation
    assert params['enable_odom_tf'] is False
    assert "'/cmd_vel_nav'" in gate
    assert "'/cmd_vel'" in gate
    assert ekf['ekf_filter_node']['ros__parameters']['odom0'] == '/wheel/odom'
    assert ekf['ekf_filter_node']['ros__parameters']['publish_tf'] is True
