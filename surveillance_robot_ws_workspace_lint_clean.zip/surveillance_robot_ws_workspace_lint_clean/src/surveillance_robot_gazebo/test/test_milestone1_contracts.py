# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Static Milestone 1 architecture contracts; runtime acceptance is separate."""

import ast
from pathlib import Path
import xml.etree.ElementTree as ET

import yaml

ROOT = Path(__file__).resolve().parents[2]
GZ = ROOT / 'surveillance_robot_gazebo'
DESC = ROOT / 'surveillance_robot_description'
LOC = ROOT / 'surveillance_robot_localization'
NAV = ROOT / 'surveillance_robot_navigation'
PATROL = ROOT / 'surveillance_robot_patrol'
HEALTH = ROOT / 'surveillance_robot_health'
BRINGUP = ROOT / 'surveillance_robot_bringup'


def test_four_wheel_single_control_chain():
    wheels = (DESC / 'urdf/wheels.xacro').read_text()
    control = (DESC / 'urdf/ros2_control.xacro').read_text()
    cfg = yaml.safe_load((GZ / 'config/controllers.yaml').read_text())['diff_drive_controller'][
        'ros__parameters'
    ]
    names = [
        'front_left_wheel',
        'rear_left_wheel',
        'front_right_wheel',
        'rear_right_wheel',
    ]
    for name in names:
        assert f'name="{name}"' in wheels
        assert f'joint="{name}_joint"' in control
    assert cfg['left_wheel_names'] == [
        'front_left_wheel_joint',
        'rear_left_wheel_joint',
    ]
    assert cfg['right_wheel_names'] == [
        'front_right_wheel_joint',
        'rear_right_wheel_joint',
    ]
    assert cfg['enable_odom_tf'] is False
    assert cfg['wheel_radius'] == 0.125
    assert cfg['wheel_separation'] == 0.525
    assert 'linear.x.min_acceleration' not in cfg
    assert 'linear.x.max_deceleration' in cfg


def test_sensor_bridge_topics_unique():
    data = yaml.safe_load((GZ / 'config/sensor_bridges.yaml').read_text())
    topics = [entry['ros_topic_name'] for entry in data]
    assert len(topics) == len(set(topics))
    required = {
        '/scan',
        '/lidar/points',
        '/camera/front/image_raw',
        '/camera/front/camera_info',
        '/camera/front/depth/image_raw',
        '/camera/front/depth/camera_info',
        '/imu/data',
    }
    assert required.issubset(topics)


def test_tf_authorities_are_explicit():
    ekf = yaml.safe_load((LOC / 'config/ekf.yaml').read_text())['ekf_filter_node'][
        'ros__parameters'
    ]
    assert ekf['publish_tf'] is True
    assert ekf['world_frame'] == 'odom'
    assert ekf['base_link_frame'] == 'base_footprint'

    slam = yaml.safe_load((LOC / 'config/slam_toolbox.yaml').read_text())['slam_toolbox'][
        'ros__parameters'
    ]
    assert (
        slam['map_frame'],
        slam['odom_frame'],
        slam['base_frame'],
    ) == ('map', 'odom', 'base_footprint')

    amcl = yaml.safe_load((LOC / 'config/amcl.yaml').read_text())['amcl']['ros__parameters']
    assert (
        amcl['global_frame_id'],
        amcl['odom_frame_id'],
        amcl['base_frame_id'],
    ) == ('map', 'odom', 'base_footprint')


def test_procedural_world_is_sensor_visible_and_moving_obstacle_collides():
    world = ET.parse(GZ / 'worlds/construction_site_procedural.sdf').getroot().find('world')
    assert world.get('name') == 'construction_site_procedural'
    obstacle = world.find("model[@name='moving_obstacle']")
    assert obstacle is not None
    assert obstacle.find('link/collision') is not None
    assert 'VelocityControl' in obstacle.find('plugin').get('name')
    assert len(world.findall('model')) > 50


def test_nav2_uses_measured_footprint_and_scan():
    cfg = yaml.safe_load((NAV / 'config/nav2_params.yaml').read_text())
    local = cfg['local_costmap']['local_costmap']['ros__parameters']
    global_ = cfg['global_costmap']['global_costmap']['ros__parameters']
    assert local['footprint'] == global_['footprint']
    assert '/scan' == local['obstacle_layer']['scan']['topic']
    assert cfg['controller_server']['ros__parameters']['FollowPath']['max_vel_x'] <= 0.6


def test_launches_parse_and_single_top_level_composition():
    for package in [GZ, LOC, NAV, PATROL, HEALTH, BRINGUP]:
        for launch in (package / 'launch').glob('*.py'):
            ast.parse(launch.read_text())
    for name in [
        'demo_mapping.launch.py',
        'demo_navigation.launch.py',
        'demo_patrol.launch.py',
    ]:
        assert (BRINGUP / 'launch' / name).is_file()

    nav_launch = (NAV / 'launch/navigation.launch.py').read_text()
    assert "FindPackageShare('nav2_bringup')" not in nav_launch
    assert 'IncludeLaunchDescription' not in nav_launch
    for required in [
        'nav2_controller',
        'nav2_planner',
        'nav2_behaviors',
        'nav2_bt_navigator',
        'nav2_waypoint_follower',
    ]:
        assert required in nav_launch
    for forbidden in [
        'nav2_route',
        'opennav_docking',
        'nav2_collision_monitor',
        'nav2_velocity_smoother',
    ]:
        assert forbidden not in nav_launch


def test_patrol_and_health_contracts():
    patrol = (PATROL / 'surveillance_robot_patrol/waypoint_patrol.py').read_text()
    for state in ['PENDING', 'ACTIVE', 'SUCCEEDED', 'FAILED', 'SKIPPED']:
        assert state in patrol
    assert 'ComputePathToPose' in patrol
    assert 'NavigateToPose' in patrol
    compact_patrol = ''.join(patrol.split())
    assert "max_attempts',3" in compact_patrol
    assert "w['state']='SKIPPED'" in compact_patrol

    health = (HEALTH / 'surveillance_robot_health/health_monitor.py').read_text()
    assert '/safety/stop_requested' in health
    assert '/health/clear_faults' in health
    assert 'msg_stamp' in health

    gate = (HEALTH / 'surveillance_robot_health/cmd_vel_safety_gate.py').read_text()
    assert "'/cmd_vel_nav'" in gate
    assert "'/cmd_vel'" in gate
