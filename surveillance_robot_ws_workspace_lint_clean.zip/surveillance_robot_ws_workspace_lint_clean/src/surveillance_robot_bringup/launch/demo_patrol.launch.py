# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def include(pkg, file, args=None):
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([FindPackageShare(pkg), 'launch', file])
        ),
        launch_arguments=(args or {}).items(),
    )


def generate_launch_description():
    return LaunchDescription(
        [
            DeclareLaunchArgument('map'),
            DeclareLaunchArgument(
                'route_file',
                default_value=PathJoinSubstitution(
                    [FindPackageShare('surveillance_robot_patrol'), 'config', 'demo_route.yaml']
                ),
            ),
            DeclareLaunchArgument('moving_obstacle', default_value='true'),
            include(
                'surveillance_robot_bringup',
                'demo_navigation.launch.py',
                {
                    'map': LaunchConfiguration('map'),
                    'moving_obstacle': LaunchConfiguration('moving_obstacle'),
                    'use_rviz': 'true',
                },
            ),
            include(
                'surveillance_robot_patrol',
                'patrol.launch.py',
                {'route_file': LaunchConfiguration('route_file'), 'auto_start': 'true'},
            ),
        ]
    )
