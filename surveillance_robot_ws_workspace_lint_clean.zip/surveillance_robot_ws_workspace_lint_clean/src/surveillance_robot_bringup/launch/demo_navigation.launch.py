# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def include(pkg, file, args=None):
    return IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([FindPackageShare(pkg), 'launch', file])
        ),
        launch_arguments=(args or {}).items(),
    )


def generate_launch_description():
    map_file = LaunchConfiguration('map')
    world = LaunchConfiguration('world')
    rviz = LaunchConfiguration('use_rviz')
    moving = LaunchConfiguration('moving_obstacle')
    sim = include(
        'surveillance_robot_gazebo',
        'simulation.launch.py',
        {'world': world, 'use_rviz': 'false', 'moving_obstacle': moving},
    )
    health = include(
        'surveillance_robot_health',
        'health.launch.py',
        {'require_localization': 'true', 'require_nav2': 'true'},
    )
    loc = include('surveillance_robot_localization', 'localization.launch.py', {'map': map_file})
    nav = include('surveillance_robot_navigation', 'navigation.launch.py')
    view = Node(
        package='rviz2',
        executable='rviz2',
        name='navigation_rviz',
        arguments=[
            '-d',
            PathJoinSubstitution(
                [FindPackageShare('surveillance_robot_localization'), 'rviz', 'navigation.rviz']
            ),
        ],
        parameters=[{'use_sim_time': True}],
        condition=IfCondition(rviz),
    )
    return LaunchDescription(
        [
            DeclareLaunchArgument('map'),
            DeclareLaunchArgument('world', default_value='construction_site_procedural'),
            DeclareLaunchArgument('moving_obstacle', default_value='false'),
            DeclareLaunchArgument('use_rviz', default_value='true'),
            sim,
            health,
            loc,
            nav,
            view,
        ]
    )
