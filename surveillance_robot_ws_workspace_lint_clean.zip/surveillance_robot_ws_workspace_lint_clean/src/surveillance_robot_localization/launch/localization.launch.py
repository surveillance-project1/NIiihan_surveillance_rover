# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pathlib import Path

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    OpaqueFunction,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def require_map(context):
    path = Path(LaunchConfiguration('map').perform(context))
    if not path.is_file():
        raise RuntimeError(f'Saved map YAML not found: {path}')
    return []


def generate_launch_description():
    pkg = FindPackageShare('surveillance_robot_localization')
    nav2 = FindPackageShare('nav2_bringup')
    return LaunchDescription(
        [
            DeclareLaunchArgument('map'),
            DeclareLaunchArgument('autostart', default_value='true'),
            OpaqueFunction(function=require_map),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    PathJoinSubstitution([pkg, 'launch', 'ekf.launch.py'])
                )
            ),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    PathJoinSubstitution(
                        [
                            nav2,
                            'launch',
                            'localization_launch.py',
                        ]
                    )
                ),
                launch_arguments={
                    'map': LaunchConfiguration('map'),
                    'use_sim_time': 'true',
                    'autostart': LaunchConfiguration('autostart'),
                    'params_file': PathJoinSubstitution(
                        [
                            pkg,
                            'config',
                            'amcl.yaml',
                        ]
                    ),
                }.items(),
            ),
        ]
    )
