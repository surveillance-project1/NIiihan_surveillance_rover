# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from glob import glob
import os

from setuptools import find_packages, setup

package_name = 'surveillance_robot_health'
setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='MAYURESH SHASTRI',
    maintainer_email='zcoerra_t151060_2025_26@zealeducation.com',
    description=(
        'Message, TF, localization, and Nav2 health monitoring with a '
        'cmd_vel safety gate.'
    ),
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'health_monitor=surveillance_robot_health.health_monitor:main',
            'cmd_vel_safety_gate=surveillance_robot_health.cmd_vel_safety_gate:main',
        ]
    },
)
