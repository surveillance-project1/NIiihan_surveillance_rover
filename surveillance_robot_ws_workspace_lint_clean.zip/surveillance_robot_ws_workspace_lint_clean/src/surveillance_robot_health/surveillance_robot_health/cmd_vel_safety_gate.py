# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from geometry_msgs.msg import TwistStamped
import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from std_msgs.msg import Bool


class CmdVelSafetyGate(Node):
    """Sole publisher to /cmd_vel; gates Nav2/teleop commands with latched health stop."""

    def __init__(self):
        super().__init__('cmd_vel_safety_gate')
        self.declare_parameter('command_timeout', 0.5)
        self.stopped = True
        self.last = None
        self.pub = self.create_publisher(TwistStamped, '/cmd_vel', 10)
        self.create_subscription(TwistStamped, '/cmd_vel_nav', self.command, 10)
        qos = QoSProfile(
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
        )
        self.create_subscription(Bool, '/safety/stop_requested', self.stop, qos)
        self.create_timer(0.05, self.tick)

    def stop(self, msg):
        self.stopped = bool(msg.data)
        if self.stopped:
            self.publish_zero()

    def command(self, msg):
        self.last = self.get_clock().now()
        if self.stopped:
            self.publish_zero()
        else:
            self.pub.publish(msg)

    def publish_zero(self):
        msg = TwistStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_footprint'
        self.pub.publish(msg)

    def tick(self):
        timeout = float(self.get_parameter('command_timeout').value)
        if (
            self.stopped
            or self.last is None
            or (self.get_clock().now() - self.last).nanoseconds / 1e9 > timeout
        ):
            self.publish_zero()


def main(args=None):
    rclpy.init(args=args)
    n = CmdVelSafetyGate()
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        rclpy.shutdown()
