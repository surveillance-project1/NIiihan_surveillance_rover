# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from collections import deque
import math

from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus, KeyValue
from nav2_msgs.action import NavigateToPose
from nav_msgs.msg import Odometry
import rclpy
from rclpy.action import ActionClient
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.qos import (
    DurabilityPolicy,
    qos_profile_sensor_data,
    QoSProfile,
    ReliabilityPolicy,
)
from sensor_msgs.msg import CameraInfo, Image, Imu, LaserScan, PointCloud2
from std_msgs.msg import Bool
from std_srvs.srv import Trigger
from tf2_ros import Buffer, TransformException, TransformListener

OK, WARN, ERROR, STALE = 0, 1, 2, 3


class Stream:
    def __init__(self, name, expected_frame, timeout, expected_rate, critical, validator):
        self.name = name
        self.frame = expected_frame
        self.timeout = timeout
        self.expected_rate = expected_rate
        self.critical = critical
        self.validator = validator
        self.rx = deque(maxlen=100)
        self.valid = False
        self.reason = 'no messages'
        self.msg_frame = ''
        self.msg_stamp = None

    def update(self, msg, now):
        self.rx.append(now)
        header = getattr(msg, 'header', None)
        self.msg_frame = getattr(header, 'frame_id', '')
        self.valid, self.reason = self.validator(msg)
        stamp = getattr(header, 'stamp', None)
        self.msg_stamp = (
            (float(stamp.sec) + float(stamp.nanosec) * 1.0e-9) if stamp is not None else None
        )
        if self.frame and self.msg_frame != self.frame:
            self.valid = False
            self.reason = f'frame {self.msg_frame!r}, expected {self.frame!r}'

    def rate(self):
        return (
            (len(self.rx) - 1) / (self.rx[-1] - self.rx[0])
            if len(self.rx) > 1 and self.rx[-1] > self.rx[0]
            else 0.0
        )


def finite(*v):
    return all(math.isfinite(float(x)) for x in v)


def laser(m):
    return (
        bool(m.ranges) and finite(m.angle_min, m.angle_max, m.range_min, m.range_max),
        'invalid/empty scan',
    )


def cloud(m):
    return (
        m.width * m.height > 0 and {'x', 'y', 'z'}.issubset({f.name for f in m.fields}),
        'empty cloud or missing xyz fields',
    )


def image(m):
    return (m.width > 0 and m.height > 0 and len(m.data) > 0, 'empty image')


def info(m):
    return (m.width > 0 and m.height > 0, 'empty camera info')


def imu(m):
    return (
        finite(
            m.angular_velocity.x,
            m.angular_velocity.y,
            m.angular_velocity.z,
            m.linear_acceleration.x,
            m.linear_acceleration.y,
            m.linear_acceleration.z,
            m.orientation.x,
            m.orientation.y,
            m.orientation.z,
            m.orientation.w,
        ),
        'non-finite IMU',
    )


def odom(m):
    return (
        finite(
            m.pose.pose.position.x,
            m.pose.pose.position.y,
            m.twist.twist.linear.x,
            m.twist.twist.angular.z,
        ),
        'non-finite odometry',
    )


class HealthMonitor(Node):
    def __init__(self):
        super().__init__('health_monitor')
        defaults = {
            'startup_grace_sec': 10.0,
            'publish_period_sec': 1.0,
            'minimum_rate_ratio': 0.6,
            'require_localization': False,
            'require_nav2': False,
            'scan_timeout': 0.5,
            'pointcloud_timeout': 2.0,
            'rgb_timeout': 2.0,
            'depth_timeout': 2.0,
            'imu_timeout': 0.5,
            'wheel_odom_timeout': 0.5,
            'fused_odom_timeout': 0.5,
            'expected_scan_rate': 10.0,
            'expected_pointcloud_rate': 5.0,
            'expected_rgb_rate': 20.0,
            'expected_depth_rate': 20.0,
            'expected_imu_rate': 100.0,
            'expected_odom_rate': 50.0,
        }
        for k, v in defaults.items():
            self.declare_parameter(k, v)

        def p(key):
            return self.get_parameter(key).value

        self.streams = {
            'LiDAR': Stream(
                'LiDAR', 'lidar_link', p('scan_timeout'), p('expected_scan_rate'), True, laser
            ),
            'Point cloud': Stream(
                'Point cloud',
                'lidar_link',
                p('pointcloud_timeout'),
                p('expected_pointcloud_rate'),
                False,
                cloud,
            ),
            'Camera RGB': Stream(
                'Camera RGB',
                'camera_front_optical_frame',
                p('rgb_timeout'),
                p('expected_rgb_rate'),
                False,
                image,
            ),
            'Camera RGB info': Stream(
                'Camera RGB info',
                'camera_front_optical_frame',
                p('rgb_timeout'),
                p('expected_rgb_rate'),
                False,
                info,
            ),
            'Depth': Stream(
                'Depth',
                'camera_front_depth_optical_frame',
                p('depth_timeout'),
                p('expected_depth_rate'),
                False,
                image,
            ),
            'Depth info': Stream(
                'Depth info',
                'camera_front_depth_optical_frame',
                p('depth_timeout'),
                p('expected_depth_rate'),
                False,
                info,
            ),
            'IMU': Stream('IMU', 'imu_link', p('imu_timeout'), p('expected_imu_rate'), False, imu),
            'Wheel odometry': Stream(
                'Wheel odometry',
                'odom',
                p('wheel_odom_timeout'),
                p('expected_odom_rate'),
                True,
                odom,
            ),
            'Odometry': Stream(
                'Odometry', 'odom', p('fused_odom_timeout'), p('expected_odom_rate'), True, odom
            ),
        }
        subs = [
            (LaserScan, '/scan', 'LiDAR'),
            (PointCloud2, '/lidar/points', 'Point cloud'),
            (Image, '/camera/front/image_raw', 'Camera RGB'),
            (CameraInfo, '/camera/front/camera_info', 'Camera RGB info'),
            (Image, '/camera/front/depth/image_raw', 'Depth'),
            (CameraInfo, '/camera/front/depth/camera_info', 'Depth info'),
            (Imu, '/imu/data', 'IMU'),
            (Odometry, '/wheel/odom', 'Wheel odometry'),
            (Odometry, '/odom', 'Odometry'),
        ]
        self._subscriptions = []
        for typ, topic, key in subs:
            self._subscriptions.append(
                self.create_subscription(
                    typ, topic, lambda m, k=key: self.receive(k, m), qos_profile_sensor_data
                )
            )
        self.tf = Buffer()
        self.listener = TransformListener(self.tf, self)
        self.nav = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.diag = self.create_publisher(DiagnosticArray, '/diagnostics', 10)
        qos = QoSProfile(
            depth=1,
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
        )
        self.stop_pub = self.create_publisher(Bool, '/safety/stop_requested', qos)
        self.create_service(Trigger, '/health/clear_faults', self.clear_faults)
        self.started = self.get_clock().now()
        self.latched = False
        self.last_summary = ''
        self.create_timer(float(p('publish_period_sec')), self.tick)

    def receive(self, key, msg):
        self.streams[key].update(msg, self.get_clock().now().nanoseconds / 1e9)

    def stream_status(self, s, now):
        if not s.rx:
            return STALE, 'UNKNOWN — no messages', 0.0
        age = now - s.rx[-1]
        rate = s.rate()
        if age > s.timeout:
            return ERROR if s.critical else WARN, f'FAULT — stale {age:.2f}s', rate
        if s.msg_stamp is None:
            return ERROR if s.critical else WARN, 'FAULT — missing timestamp', rate
        stamp_age = now - s.msg_stamp
        if now > 0.0 and s.msg_stamp <= 0.0:
            return ERROR if s.critical else WARN, 'FAULT — zero timestamp', rate
        if stamp_age > s.timeout:
            return (
                ERROR if s.critical else WARN,
                f'FAULT — message timestamp stale {stamp_age:.2f}s',
                rate,
            )
        if stamp_age < -0.10:
            return (
                ERROR if s.critical else WARN,
                f'FAULT — message timestamp is {-stamp_age:.2f}s in the future',
                rate,
            )
        if not s.valid:
            return ERROR if s.critical else WARN, f'FAULT — {s.reason}', rate
        if rate and rate < s.expected_rate * float(self.get_parameter('minimum_rate_ratio').value):
            return WARN, f'DEGRADED — {rate:.1f} Hz', rate
        return OK, f'HEALTHY — {rate:.1f} Hz', rate

    def tf_ok(self, target, source):
        try:
            self.tf.lookup_transform(
                target, source, rclpy.time.Time(), timeout=Duration(seconds=0.05)
            )
            return True, ''
        except TransformException as e:
            return False, str(e)

    def status(self, name, level, message, values=None):
        d = DiagnosticStatus(
            name=name, hardware_id='surveillance_robot_sim', level=level, message=message
        )
        d.values = [KeyValue(key=k, value=str(v)) for k, v in (values or {}).items()]
        return d

    def evaluate(self, publish=True):
        now = self.get_clock().now().nanoseconds / 1e9
        arr = []
        critical = False
        summary = []
        for s in self.streams.values():
            level, msg, rate = self.stream_status(s, now)
            arr.append(
                self.status(
                    s.name,
                    level,
                    msg,
                    {
                        'rate_hz': f'{rate:.2f}',
                        'frame': s.msg_frame,
                        'message_stamp': s.msg_stamp,
                        'critical': s.critical,
                    },
                )
            )
            summary.append(f'{s.name}: {msg}')
            critical |= s.critical and level in (ERROR, STALE)
        tf_checks = [
            ('TF sensor', 'base_footprint', 'lidar_link', True),
            ('TF camera', 'base_footprint', 'camera_front_optical_frame', False),
            ('TF IMU', 'base_footprint', 'imu_link', True),
            ('TF odometry', 'odom', 'base_footprint', True),
        ]
        for name, target, source, iscritical in tf_checks:
            ok, reason = self.tf_ok(target, source)
            level = OK if ok else ERROR
            arr.append(
                self.status(
                    name,
                    level,
                    'HEALTHY' if ok else 'FAULT',
                    {'edge': f'{target}->{source}', 'reason': reason},
                )
            )
            critical |= iscritical and not ok
        loc_ok, reason = self.tf_ok('map', 'odom')
        req_loc = bool(self.get_parameter('require_localization').value)
        arr.append(
            self.status(
                'Localization',
                OK if loc_ok else (ERROR if req_loc else STALE),
                'HEALTHY' if loc_ok else ('FAULT' if req_loc else 'UNKNOWN'),
                {'reason': reason},
            )
        )
        critical |= req_loc and not loc_ok
        nav_ok = self.nav.server_is_ready()
        req_nav = bool(self.get_parameter('require_nav2').value)
        arr.append(
            self.status(
                'Nav2',
                OK if nav_ok else (ERROR if req_nav else STALE),
                'ACTIVE' if nav_ok else ('FAULT' if req_nav else 'INACTIVE'),
            )
        )
        critical |= req_nav and not nav_ok
        grace = (self.get_clock().now() - self.started).nanoseconds / 1e9 < float(
            self.get_parameter('startup_grace_sec').value
        )
        if critical and not grace:
            self.latched = True
        if publish:
            msg = DiagnosticArray()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.status = arr
            self.diag.publish(msg)
            stop = Bool()
            stop.data = self.latched
            self.stop_pub.publish(stop)
            tf_fault = any(
                item.level == ERROR and item.name.startswith('TF')
                for item in arr
            )
            tf_state = 'FAULT' if tf_fault else 'HEALTHY'
            localization_state = 'HEALTHY' if loc_ok else 'UNKNOWN/FAULT'
            nav2_state = 'ACTIVE' if nav_ok else 'INACTIVE'
            text = ' | '.join(
                summary
                + [
                    f'TF: {tf_state}',
                    f'Localization: {localization_state}',
                    f'Nav2: {nav2_state}',
                    f'STOP: {self.latched}',
                ]
            )
            if text != self.last_summary:
                self.get_logger().info(text)
                self.last_summary = text
        return critical and not grace

    def clear_faults(self, request, response):
        if self.evaluate(False):
            response.success = False
            response.message = 'Critical health condition remains'
        else:
            self.latched = False
            response.success = True
            response.message = 'Health stop cleared; motion remains command-driven'
        return response

    def tick(self):
        self.evaluate(True)


def main(args=None):
    rclpy.init(args=args)
    n = HealthMonitor()
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        rclpy.shutdown()
