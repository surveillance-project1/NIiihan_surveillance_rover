# Copyright 2026 MAYURESH SHASTRI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    cfg = PathJoinSubstitution(
        [FindPackageShare('surveillance_robot_health'), 'config', 'health.yaml']
    )
    return LaunchDescription(
        [
            DeclareLaunchArgument('require_localization', default_value='false'),
            DeclareLaunchArgument('require_nav2', default_value='false'),
            Node(
                package='surveillance_robot_health',
                executable='health_monitor',
                name='health_monitor',
                output='screen',
                parameters=[
                    cfg,
                    {
                        'require_localization': ParameterValue(
                            LaunchConfiguration('require_localization'), value_type=bool
                        ),
                        'require_nav2': ParameterValue(
                            LaunchConfiguration('require_nav2'), value_type=bool
                        ),
                    },
                ],
            ),
            Node(
                package='surveillance_robot_health',
                executable='cmd_vel_safety_gate',
                name='cmd_vel_safety_gate',
                output='screen',
                parameters=[cfg],
            ),
        ]
    )
