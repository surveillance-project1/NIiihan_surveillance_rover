# Saved-Map Localization and Navigation — Milestone 1

This document supersedes the historical “Chunk 7” commands.

```bash
ros2 launch surveillance_robot_bringup demo_navigation.launch.py \
  map:=/absolute/path/to/site.yaml
```

Navigation mode starts one simulation, health gate, EKF, Map Server, AMCL, the minimal Nav2 server set and navigation RViz. AMCL is the sole `map -> odom` authority. Set the initial pose in RViz before sending a goal.

The Nav2 launch intentionally starts only:

- controller server
- smoother server
- planner server
- behavior server
- BT navigator
- waypoint follower
- lifecycle manager

Route server, docking, collision monitor and velocity smoother are not launched in Milestone 1. Nav2/behavior commands use stamped `/cmd_vel_nav`; the health gate is the sole publisher to controller input `/cmd_vel`.

For patrol and the moving-obstacle scenario, use `demo_patrol.launch.py` as documented in [MILESTONE1.md](MILESTONE1.md).

**Runtime status: NOT VERIFIED in the source-repair environment.**
