# Mapping Mode — Milestone 1

This document supersedes the historical “Chunk 6” commands.

```bash
ros2 launch surveillance_robot_bringup demo_mapping.launch.py
```

The launch composes one Gazebo server and robot, sensor bridges, ros2_control, the health gate, EKF, SLAM Toolbox and mapping RViz. SLAM Toolbox is the sole `map -> odom` authority; EKF is the sole `odom -> base_footprint` authority.

Drive through `/cmd_vel_nav` using the stamped teleoperation command documented in [MILESTONE1.md](MILESTONE1.md). Save the map with `nav2_map_server map_saver_cli`. Do not run AMCL in mapping mode.

Default environment: `construction_site_procedural`. The legacy `construction_site_chunk5` world is collision-only and unsuitable for sensor-based mapping validation.

**Runtime status: NOT VERIFIED in the source-repair environment.**
